"""
ChemVideo AI - Video Processor (Python)

Optimized frame-by-frame stroke detection using OpenCV VideoCapture.

Pipeline:
  1. cv2.VideoCapture opens the video and reads fps / dimensions / frame count.
  2. Frames are SAMPLED at the requested analysis fps via efficient seeking
     (cap.set CAP_PROP_POS_FRAMES) — no ffmpeg PNG extraction and no disk I/O,
     so only the frames actually needed are decoded.
  3. Each sampled frame is downscaled to max_width (default 1280), preserving
     aspect ratio, then converted to grayscale.
  4. Absolute difference between consecutive sampled frames isolates new ink.
  5. Threshold + morphological opening removes noise / static UI (cursor, borders).
  6. Contours below a min area are ignored (static elements / speckle).
  7. Contours are tracked across frames (overlap / center proximity) into strokes.
  8. Each stroke gets a bounding box, start/end time, stroke path, and a crop.
  9. Objects are ordered chronologically and returned as a Stroke Timeline.

No timestamps, bounding boxes, or stroke data are invented: every value comes
from a real decoded frame and a real detected contour.
"""

import os
import math
import uuid

import cv2

SUPPORTED_EXT = {"mp4", "mov", "webm", "mkv", "avi"}
MAX_FRAMES = 4000
DEFAULT_MAX_WIDTH = 1280


def ext_of(filename):
    if not filename or "." not in filename:
        return ""
    return filename.rsplit(".", 1)[-1].lower()


def _open_video(path):
    cap = cv2.VideoCapture(path)
    if not cap.isOpened():
        return None
    src_fps = float(cap.get(cv2.CAP_PROP_FPS) or 0.0)
    frame_count = int(cap.get(cv2.CAP_PROP_FRAME_COUNT) or 0)
    src_w = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH) or 0)
    src_h = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT) or 0)
    return cap, src_fps, frame_count, src_w, src_h


def get_meta(path):
    """Return {duration, width, height, fps, frame_count} via OpenCV, or None."""
    info = _open_video(path)
    if not info:
        return None
    cap, src_fps, frame_count, src_w, src_h = info
    cap.release()
    if not src_w or not src_h:
        return None
    duration = (frame_count / src_fps) if (src_fps > 0 and frame_count > 0) else 0.0
    return {
        "duration": duration,
        "width": src_w,
        "height": src_h,
        "fps": src_fps,
        "frame_count": frame_count,
    }


def _iou(a, b):
    x1 = max(a["x"], b["x"]); y1 = max(a["y"], b["y"])
    x2 = min(a["x"] + a["w"], b["x"] + b["w"]); y2 = min(a["y"] + a["h"], b["y"] + b["h"])
    inter = max(0, x2 - x1) * max(0, y2 - y1)
    union = a["w"] * a["h"] + b["w"] * b["h"] - inter
    return inter / union if union > 0 else 0


def _union(a, b):
    x1 = min(a["x"], b["x"]); y1 = min(a["y"], b["y"])
    x2 = max(a["x"] + a["w"], b["x"] + b["w"]); y2 = max(a["y"] + a["h"], b["y"] + b["h"])
    return {"x": x1, "y": y1, "w": x2 - x1, "h": y2 - y1}


def _proc_dimensions(src_w, src_h, max_width):
    """Downscale to max_width preserving aspect ratio; force even dimensions."""
    if src_w > max_width:
        scale = max_width / src_w
        proc_w = max_width
        proc_h = max(2, int(round(src_h * scale)))
    else:
        proc_w, proc_h = src_w, src_h
    proc_w -= proc_w % 2
    proc_h -= proc_h % 2
    return proc_w, proc_h


def _decode_at(cap, pos, need_resize, proc_w, proc_h):
    """Seek to source frame `pos` (or read next when None), decode, optionally downscale."""
    if pos is not None:
        cap.set(cv2.CAP_PROP_POS_FRAMES, pos)
    ok, frame = cap.read()
    if not ok or frame is None:
        return None
    if need_resize:
        frame = cv2.resize(frame, (proc_w, proc_h), interpolation=cv2.INTER_AREA)
    return frame


def process_video(video_path, fps=1, sensitivity=0.5, max_width=DEFAULT_MAX_WIDTH,
                  crops_dir=None, crops_base_url=""):
    fps = max(1, min(30, int(fps) if fps else 1))
    sensitivity = max(0.0, min(1.0, float(sensitivity) if sensitivity is not None else 0.5))
    max_width = max(320, int(max_width) if max_width else DEFAULT_MAX_WIDTH)

    info = _open_video(video_path)
    if not info:
        raise ValueError("CORRUPTED")
    cap, src_fps, frame_count, src_w, src_h = info

    try:
        if not src_w or not src_h:
            raise ValueError("CORRUPTED")

        proc_w, proc_h = _proc_dimensions(src_w, src_h, max_width)
        need_resize = (proc_w != src_w)

        src_fps = src_fps if src_fps > 0 else 30.0
        duration = (frame_count / src_fps) if frame_count > 0 else 0.0

        stride = max(1, round(src_fps / fps))

        # Build sample positions (source frame indices) for efficient seeking.
        positions = None
        if frame_count > 0:
            positions = list(range(0, frame_count, stride))
            if len(positions) > MAX_FRAMES:
                step = math.ceil(len(positions) / MAX_FRAMES)
                positions = positions[::step]
        # If frame_count is unknown, pass 1 falls back to sequential sampling.

        diff_threshold = int(round(40 - sensitivity * 25))   # ~15..40
        min_area = int(round(150 - sensitivity * 120))      # ~30..150
        idle_to_close = max(1, round(fps * 0.4))
        kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (5, 5))

        active = []
        closed = []
        prev_gray = None
        frames_processed = 0

        # --- Pass 1: sample frames, run stroke detection (grayscale only) ---
        i = 0
        while True:
            if positions is not None:
                if i >= len(positions):
                    break
                pos = positions[i]
                t = pos / src_fps
            else:
                pos = None
                t = i * stride / src_fps

            frame = _decode_at(cap, pos, need_resize, proc_w, proc_h)
            if frame is None:
                break
            curr_gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
            frames_processed += 1

            if prev_gray is not None:
                diff = cv2.absdiff(prev_gray, curr_gray)
                _, thresh = cv2.threshold(diff, diff_threshold, 255, cv2.THRESH_BINARY)
                opened = cv2.morphologyEx(thresh, cv2.MORPH_OPEN, kernel)
                contours, _ = cv2.findContours(opened, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

                detected = []
                for c in contours:
                    if cv2.contourArea(c) < min_area:
                        continue
                    x, y, w, h = cv2.boundingRect(c)
                    detected.append({"x": x, "y": y, "w": w, "h": h,
                                     "cx": x + w / 2, "cy": y + h / 2})

                used = set()
                for stroke in active:
                    best = None
                    best_score = 0
                    for idx, d in enumerate(detected):
                        if idx in used:
                            continue
                        overlap = _iou(stroke["bbox"], d)
                        dist = ((stroke["cx"] - d["cx"]) ** 2 + (stroke["cy"] - d["cy"]) ** 2) ** 0.5
                        score = overlap if overlap > 0 else (0.1 if dist < 60 else 0)
                        if score > best_score:
                            best_score = score
                            best = (idx, d)
                    if best:
                        idx, d = best
                        used.add(idx)
                        stroke["last_frame"] = i
                        stroke["idle"] = 0
                        stroke["bbox"] = _union(stroke["bbox"], d)
                        stroke["cx"] = d["cx"]
                        stroke["cy"] = d["cy"]
                        stroke["points"].append({"x": d["cx"] / proc_w, "y": d["cy"] / proc_h, "t": t})
                    else:
                        stroke["idle"] = stroke.get("idle", 0) + 1
                        if stroke["idle"] >= idle_to_close:
                            stroke["closed"] = True
                            closed.append(stroke)

                for idx, d in enumerate(detected):
                    if idx in used:
                        continue
                    active.append({
                        "id": str(uuid.uuid4()),
                        "start_frame": i,
                        "last_frame": i,
                        "idle": 0,
                        "closed": False,
                        "bbox": {"x": d["x"], "y": d["y"], "w": d["w"], "h": d["h"]},
                        "cx": d["cx"], "cy": d["cy"],
                        "points": [{"x": d["cx"] / proc_w, "y": d["cy"] / proc_h, "t": t}],
                        "start_pos": pos,
                    })

            prev_gray = curr_gray
            i += 1

        for s in active:
            if not s.get("closed"):
                closed.append(s)
        closed.sort(key=lambda s: s["start_frame"])

        if frames_processed < 2:
            return {
                "status": "completed",
                "video_duration": round(duration, 3),
                "frame_rate": fps,
                "frames_processed": frames_processed,
                "analysis_precision": "frame_based",
                "timeline": [],
                "note": "Not enough frames decoded to detect strokes.",
            }

        # --- Pass 2: re-seek to each stroke's start and write the crop ---
        if crops_dir:
            os.makedirs(crops_dir, exist_ok=True)
        timeline = []
        for idx, s in enumerate(closed):
            start_time = s["start_frame"] / fps
            end_time = (s["last_frame"] + 1) / fps
            crop_url = None
            start_pos = s.get("start_pos")
            if crops_dir and start_pos is not None:
                try:
                    img = _decode_at(cap, start_pos, need_resize, proc_w, proc_h)
                    if img is not None:
                        b = s["bbox"]
                        x = max(0, int(b["x"]))
                        y = max(0, int(b["y"]))
                        w = min(proc_w - x, max(1, int(b["w"])))
                        h = min(proc_h - y, max(1, int(b["h"])))
                        crop = img[y:y + h, x:x + w]
                        crop_name = f"{s['id']}.png"
                        cv2.imwrite(os.path.join(crops_dir, crop_name), crop)
                        crop_url = f"{crops_base_url}/crops/{crop_name}"
                except Exception:
                    pass

            b = s["bbox"]
            timeline.append({
                "id": s["id"],
                "order": idx + 1,
                "start_time": round(start_time, 3),
                "end_time": round(end_time, 3),
                "x": round(b["x"] / proc_w, 4),
                "y": round(b["y"] / proc_h, 4),
                "width": round(b["w"] / proc_w, 4),
                "height": round(b["h"] / proc_h, 4),
                "stroke_data": [
                    {"x": round(p["x"], 4), "y": round(p["y"], 4), "t": round(p["t"], 3)}
                    for p in s["points"]
                ],
                "crop_url": crop_url,
                "recognized_content": "",
                "object_type": "unknown",
                "confidence": 0,
            })

        return {
            "status": "completed",
            "video_duration": round(duration, 3),
            "frame_rate": fps,
            "frames_processed": frames_processed,
            "analysis_precision": "frame_based",
            "timeline": timeline,
        }
    finally:
        try:
            cap.release()
        except Exception:
            pass